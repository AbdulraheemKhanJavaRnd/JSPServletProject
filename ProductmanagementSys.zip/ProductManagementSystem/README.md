# JSP/Servlet-Exam

This is a product management app in which user can register,login and perform all CRUD operations related to corresponding product.
in this app without login you can't access any CRUD operations related to product.
In  this application I created seperate packages for Dao, Model, Database configurations and servlet
you can run this programme by running home.jsp file inside webapp of the product_management directory.


