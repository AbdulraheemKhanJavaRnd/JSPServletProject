package com.java.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


public class dbUtility {

	private static Connection con;

	static {

		String connecter="com.mysql.cj.jdbc.Driver";
		String idandconnect="jdbc:mysql://localhost:3306/productsDB?user=root&password=root";
		try {
			Class.forName(connecter);
			con = DriverManager.getConnection(idandconnect);
		} catch (Exception e) {

			e.printStackTrace();
		}

	}

	public boolean test_db() {

		if (con == null)
			return false;
		else
			return true;
	}
	
	public PreparedStatement Create(String sql) throws SQLException {
		
		return con.prepareStatement(sql);	}
	
	public int update(PreparedStatement pdst) throws SQLException {
		
		return pdst.executeUpdate();
		
	}
	public ResultSet query(PreparedStatement pdst) throws SQLException {
		
		return pdst.executeQuery();
	}

}
