package com.java.model;

public class product_detail {
	private int id;
	private String productname;
	private int productprice;
	private int productquantity;
	private String productvendor;
	private int productwarranty;
	public void productDetail() {
		super();
		// TODO Auto-generated constructor stub
	
		this.id = id;
		this.productname = productname;
		this.productprice = productprice;
		this.productquantity = productquantity;
		this.productvendor = productvendor;
		this.productwarranty = productwarranty;
	}
	public product_detail() {
		// TODO Auto-generated constructor stub
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getPname() {
		return productname;
	}
	public void setPname(String pname) {
		this.productname = pname;
	}
	public int getPrice() {
		return productquantity;
	}
	public void setPrice(int price) {
		this.productquantity = price;
	}
	public int getQuantity() {
		return productquantity;
	}
	public void setQuantity(int quantity) {
		this.productquantity = quantity;
	}
	public String getVendor() {
		return productname;
	}
	public void setVendor(String vendor) {
		this.productname = vendor;
	}
	public int getWarranty() {
		return productwarranty;
	}
	public void setWarranty(int warranty) {
		this.productwarranty = warranty;
	}
	
	
	
}
