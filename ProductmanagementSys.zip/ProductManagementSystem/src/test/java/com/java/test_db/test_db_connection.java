package com.java.test_db;

import com.java.db.dbUtility;

public class test_db_connection {
	
	
	public void test() {
	dbUtility check = new dbUtility();
	System.out.println(check.test_db());
	
	
	}

}
